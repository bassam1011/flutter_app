import 'dart:ui';
import 'package:flutter/material.dart';

class AppTheme {
  static const Color bgStart = Color(0xFF0A0F1C);
  static const Color bgEnd = Color(0xFF1B2235);
  static const Color gold = Color(0xFFFFD700);
  static const Color softGrey = Color(0xFF9FA8BA);

  /// خلفية احترافية (إما صورة أو Gradient)
  static Widget luxuryBackground({required Widget child}) {
    return Stack(
      children: [
        // خلفية صورة فخمة
        Positioned.fill(
          child: Image.asset(
            "assets/bg_luxury.jpg", // ضع صورة عالية الجودة هنا
            fit: BoxFit.cover,
          ),
        ),

        // Blur + لون متدرج خفيف يضيف عمق
        Positioned.fill(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    bgStart,
                    bgEnd,
                    Color(0xFF2A3350), // لمسة إضافية
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
          ),
        ),

        // المحتوى
        child,
      ],
    );
  }

  static ThemeData get luxuryTheme {
    final base = ThemeData.dark();
    return base.copyWith(
      useMaterial3: true,
      scaffoldBackgroundColor: Colors.transparent, // خليها شفافة للخلفية
      colorScheme: const ColorScheme.dark(
        primary: gold,
        onPrimary: Colors.black,
        secondary: softGrey,
        surface: Color(0xFF111827),
        onSurface: Colors.white,
      ),
      textTheme: const TextTheme(
        displayLarge: TextStyle(
          fontSize: 32,
          fontWeight: FontWeight.bold,
          color: gold,
          letterSpacing: 1.2,
        ),
        bodyLarge: TextStyle(
          color: Colors.white,
          fontSize: 18,
        ),
        bodyMedium: TextStyle(
          color: softGrey,
          fontSize: 15,
        ),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          color: gold,
          fontSize: 22,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.1,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        
        fillColor: Colors.white.withOpacity(0.05),
        hintStyle: const TextStyle(color: Color(0xFF7E8C9E)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: gold.withOpacity(0.4), width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: gold, width: 1.5),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          foregroundColor: Colors.black,
          backgroundColor: gold,
          elevation: 12,
          shadowColor: gold.withOpacity(0.6),
          textStyle: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: gold.withOpacity(0.7), width: 1.2),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          foregroundColor: gold,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          textStyle: const TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 15,
          ),
        ),
      ),
    );
  }
}
