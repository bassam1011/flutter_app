import 'package:flutter/material.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/auth_button.dart';

class SignUpScreen extends StatefulWidget {
  static const routeName = '/signup';
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _obscure = true;
  
  bool get isDark => true;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState?.validate() ?? false) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إنشاء حساب (محاكاة)')));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color.fromARGB(221, 225, 183, 183)),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: size.width > 700 ? 700 : size.width),
            child: Column(
              children: [
                const SizedBox(height: 6),
                Text('إنشاء حساب جديد', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700,color: isDark ? Colors.white70 : const Color.fromARGB(137, 204, 212, 224))),
                const SizedBox(height: 6),
                Text(' انشى حساب جديد واحصل على منتج مجانا ', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: isDark ? Colors.white70 : const Color.fromARGB(137, 204, 212, 224))),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 14, offset: const Offset(0, 10))],
                  ),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        CustomTextField(label: 'الاسم الكامل', hint: 'أدخل اسمك', controller: _name, validator: (v) => (v == null || v.trim().isEmpty) ? 'الاسم مطلوب' : null),
                        const SizedBox(height: 12),
                        CustomTextField(label: 'البريد الإلكتروني', hint: 'example@mail.com', controller: _email, keyboardType: TextInputType.emailAddress, validator: (v) {
                          if (v == null || v.trim().isEmpty) return 'البريد مطلوب';
                          if (!RegExp(r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}").hasMatch(v)) return 'صيغة البريد غير صحيحة';
                          return null;
                        }),
                        const SizedBox(height: 12),
                        CustomTextField(label: 'كلمة المرور', hint: 'الحد الأدنى 6 أحرف', controller: _password, obscure: _obscure, validator: (v) {
                          if (v == null || v.trim().isEmpty) return 'كلمة المرور مطلوبة';
                          if (v.length < 6) return 'الحد الأدنى 6 أحرف';
                          return null;
                        }, suffix: IconButton(onPressed: () => setState(() => _obscure = !_obscure), icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility))),
                        const SizedBox(height: 12),
                        CustomTextField(label: 'تأكيد كلمة المرور', hint: 'أعد إدخال كلمة المرور', controller: _confirm, obscure: _obscure, validator: (v) {
                          if (v == null || v.trim().isEmpty) return 'التأكيد مطلوب';
                          if (v != _password.text) return 'كلمتا المرور غير متطابقتين';
                          return null;
                        }),
                        const SizedBox(height: 16),
                        GradientButton(label: 'إنشاء حساب', onPressed: _submit),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text('لديك حساب؟'),
                            TextButton(onPressed: () => Navigator.pop(context), child: const Text('تسجيل الدخول'))
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
