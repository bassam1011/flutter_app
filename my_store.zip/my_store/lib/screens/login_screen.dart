import 'dart:ui';
import 'package:flutter/material.dart';
import '../widgets/auth_button.dart'; // افترض أن هذا موجود وزر GradientButton معرف فيه

class LoginScreen extends StatefulWidget {
  static const routeName = '/';
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _obscure = true;

  late final AnimationController _animController;
  late final Animation<double> _fadeIn;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeIn = CurvedAnimation(
      parent: _animController,
      curve: Curves.easeOutCubic,
    );
    _animController.forward();
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _animController.dispose();
    super.dispose();
  }

  void _submit() {
    final valid = _formKey.currentState?.validate() ?? false;
    if (valid) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تسجيل الدخول ناجح (محاكاة)')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('هناك أخطاء في النموذج — يرجى التصحيح')),
      );
    }
  }

  // دالة معالجة الضغط على أيقونات الشبكات (محاكاة)
  void _handleSocial(String provider) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('$provider — تم الضغط (محاكاة)')));
  }

  InputDecoration _inputDecoration({required String hint, Widget? suffix}) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(fontSize: 14, color: Colors.black54),
      filled: true,
      isDense: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.blue.shade400, width: 1.4),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.red.shade400),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.red.shade600, width: 1.6),
      ),
      suffixIcon: suffix,
      errorStyle: const TextStyle(fontSize: 12, height: 1.1),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final size = mq.size;
    final topPadding = mq.padding.top + mq.padding.bottom;
    final keyboardHeight = mq.viewInsets.bottom;

    // كبرنا عامل الكارد شوي حتى يظهر المحتوى والايقونات بدون أخطاء
    final baseCardFactor = 0.58;
    final keyboardReductionFactor = keyboardHeight > 0 ? 0.82 : 1.0;
    final cardFactor = (baseCardFactor * keyboardReductionFactor).clamp(
      0.35,
      0.78,
    );

    final cardMaxHeight = (size.height - topPadding) * cardFactor;

    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          // خلفية متدرجة هادئة
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF07142A), Color(0xFF043A6B)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),

          // زخارف دائرية شفافة
          Positioned(
            left: -size.width * 0.28,
            top: -size.height * 0.14,
            child: Container(
              width: size.width * 0.84,
              height: size.width * 0.84,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [Colors.white.withOpacity(0.03), Colors.transparent],
                ),
              ),
            ),
          ),

          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Container(color: Colors.black.withOpacity(0.08)),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: _fadeIn,
              child: Center(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final availableHeight =
                        constraints.maxHeight - keyboardHeight;
                    // زدنا الحد الأدنى والأقصى لارتفاع الكارد
                    final cardHeight = cardMaxHeight.clamp(
                      430.0,
                      availableHeight * 0.80,
                    );

                    return SingleChildScrollView(
                      physics: const ClampingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 18,
                      ),
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                          minHeight: availableHeight * 0.60,
                          maxHeight: availableHeight,
                        ),
                        child: IntrinsicHeight(
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              const SizedBox(height: 6),

                              // لوجو صغير جداً للحفاظ على المساحة
                              Hero(
                                tag: 'logo',
                                child: Container(
                                  width: 64, // حجم أوضح (تقدر تصغره لو تبغى)
                                  height: 40,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.2),
                                        blurRadius: 12,
                                        offset: const Offset(0, 6),
                                      ),
                                    ],
                                    image: const DecorationImage(
                                      image: AssetImage(
                                        'images\logo.png',
                                      ), // عدّل المسار حسب مجلدك
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),

                              const SizedBox(height: 7),

                              Text(
                                'مرحباً — سجّل دخولك',
                                style: Theme.of(context).textTheme.titleMedium
                                    ?.copyWith(
                                      color: Colors.white70,
                                      fontWeight: FontWeight.w600,
                                    ),
                              ),

                              const SizedBox(height: 8),

                              // الكارد الرئيسي - أكبر شوي الآن
                              Center(
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 220),
                                  curve: Curves.easeOut,
                                  height: cardHeight,
                                  width: size.width > 720
                                      ? 560
                                      : size.width * 0.94,
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.98),
                                    borderRadius: BorderRadius.circular(16),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.16),
                                        blurRadius: 26,
                                        offset: const Offset(0, 12),
                                      ),
                                    ],
                                    border: Border.all(
                                      color: Colors.white.withOpacity(0.7),
                                    ),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.stretch,
                                      children: [
                                        // رأس الكارد: عنوان صغير
                                        SizedBox(
                                          height: 35,
                                          child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  'تسجيل الدخول',
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .titleLarge
                                                      ?.copyWith(
                                                        fontSize: 19,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                ),
                                              ),
                                              Container(
                                                width: 6,
                                                height: 30,
                                                decoration: BoxDecoration(
                                                  gradient:
                                                      const LinearGradient(
                                                        colors: [
                                                          Color(0xFFFFD36E),
                                                          Color(0xFFFFA726),
                                                        ],
                                                        begin:
                                                            Alignment.topCenter,
                                                        end: Alignment
                                                            .bottomCenter,
                                                      ),
                                                  borderRadius:
                                                      BorderRadius.circular(8),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),

                                        const SizedBox(height: 8),

                                        // ---------- الجزء القابل للتمرير (الحقول) ----------
                                        // رفعنا النسبة المسموح بها للحقل حتى لا تختفي الأيقونات
                                        ConstrainedBox(
                                          constraints: BoxConstraints(
                                            // زودنا المساحة المتاحة للحقول لتجنب إخفاء الأيقونات أو الضغط على المحتوى
                                            maxHeight: cardHeight * 0.72,
                                          ),
                                          child: SingleChildScrollView(
                                            physics:
                                                const BouncingScrollPhysics(),
                                            child: Form(
                                              key: _formKey,
                                              autovalidateMode: AutovalidateMode
                                                  .onUserInteraction,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.stretch,
                                                children: [
                                                  // البريد
                                                  TextFormField(
                                                    controller: _email,
                                                    keyboardType: TextInputType
                                                        .emailAddress,
                                                    style: const TextStyle(
                                                      fontSize: 14,
                                                      color: Colors.black87,
                                                    ),
                                                    decoration: _inputDecoration(
                                                      hint:
                                                          'البريد الإلكتروني (مثال: you@mail.com)',
                                                    ),
                                                    validator: (v) {
                                                      if (v == null ||
                                                          v.trim().isEmpty)
                                                        return 'البريد مطلوب';
                                                      if (!RegExp(
                                                        r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}",
                                                      ).hasMatch(v))
                                                        return 'صيغة البريد غير صحيحة';
                                                      return null;
                                                    },
                                                  ),

                                                  const SizedBox(height: 12),

                                                  // كلمة المرور
                                                  TextFormField(
                                                    controller: _password,
                                                    obscureText: _obscure,
                                                    style: const TextStyle(
                                                      fontSize: 14,
                                                      color: Colors.black87,
                                                    ),
                                                    decoration: _inputDecoration(
                                                      hint: 'كلمة المرور',
                                                      suffix: IconButton(
                                                        onPressed: () =>
                                                            setState(
                                                              () => _obscure =
                                                                  !_obscure,
                                                            ),
                                                        icon: Icon(
                                                          _obscure
                                                              ? Icons
                                                                    .visibility_off
                                                              : Icons
                                                                    .visibility,
                                                        ),
                                                      ),
                                                    ),
                                                    validator: (v) {
                                                      if (v == null ||
                                                          v.trim().isEmpty)
                                                        return 'كلمة المرور مطلوبة';
                                                      if (v.length < 6)
                                                        return 'الحد الأدنى 6 أحرف';
                                                      return null;
                                                    },
                                                  ),

                                                  const SizedBox(height: 10),

                                                  Align(
                                                    alignment:
                                                        Alignment.centerRight,
                                                    child: TextButton(
                                                      onPressed: () =>
                                                          Navigator.pushNamed(
                                                            context,
                                                            '/forgot',
                                                          ),
                                                      child: const Text(
                                                        'نسيت كلمة المرور؟',
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),

                                        const SizedBox(height: 10),

                                        // ---------- الأزرار ثابتة خارج منطقة التمرير ----------
                                        GradientButton(
                                          label: 'تسجيل الدخول',
                                          onPressed: _submit,
                                        ),

                                        const SizedBox(height: 10),

                                        Row(
                                          children: const [
                                            Expanded(child: Divider()),
                                            Padding(
                                              padding: EdgeInsets.symmetric(
                                                horizontal: 8.0,
                                              ),
                                              child: Text('أو سجل عبر'),
                                            ),
                                            Expanded(child: Divider()),
                                          ],
                                        ),

                                        const SizedBox(height: 10),

                                        // أيقونات الشبكات الآن تستخدم Material + InkWell وتقبل الضغط
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            _buildAuthCircle(
                                              icon: Icons.g_mobiledata,
                                              color: const Color(0xFFDB4437),
                                              semanticLabel: 'تسجيل بحساب جوجل',
                                              onTap: () =>
                                                  _handleSocial('Google'),
                                            ),
                                            const SizedBox(width: 12),
                                            _buildAuthCircle(
                                              icon: Icons.facebook,
                                              color: const Color(0xFF1877F2),
                                              semanticLabel:
                                                  'تسجيل بحساب فيسبوك',
                                              onTap: () =>
                                                  _handleSocial('Facebook'),
                                            ),
                                            const SizedBox(width: 12),
                                            _buildAuthCircle(
                                              icon: Icons.apple,
                                              color: Colors.black,
                                              semanticLabel: 'تسجيل بحساب آبل',
                                              onTap: () =>
                                                  _handleSocial('Apple'),
                                            ),
                                          ],
                                        ),

                                        const SizedBox(height: 8),

                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            const Text('لا تملك حساب؟'),
                                            TextButton(
                                              onPressed: () =>
                                                  Navigator.pushNamed(
                                                    context,
                                                    '/signup',
                                                  ),
                                              child: const Text('إنشاء حساب'),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),

                              const SizedBox(height: 12),

                              Text(
                                'تصميم احترافي · تجربة مستخدم سلسة',
                                style: Theme.of(context).textTheme.bodySmall
                                    ?.copyWith(color: Colors.white70),
                              ),

                              const SizedBox(height: 8),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ويدجت أيقونات الشبكات القابلة للضغط مع تأثير ripple ونطاق لمس أكبر
  Widget _buildAuthCircle({
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
    String? semanticLabel,
  }) {
    return Material(
      color: Colors.transparent,
      shape: const CircleBorder(),
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        splashFactory: InkRipple.splashFactory,
        splashColor: Colors.black12,
        child: Container(
          width: 54, // حجم لمس مريح
          height: 54,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.08),
                blurRadius: 8,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Semantics(
            label: semanticLabel ?? 'auth icon',
            button: true,
            child: Icon(icon, color: color, size: 22),
          ),
        ),
      ),
    );
  }
}
